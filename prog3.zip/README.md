Coulby Nguyen 932-439-525
Programming Assignment 3

To Compile/Run:
Enter on the command line: python3 sentiment.py


this will run and the following files will be created if not already present
-results.txt (this holds the data that tells what percentages passed the classifier
  as well as the instances where the classifier chose wrong)
-preprocessed_test.txt (this file holds the data of the testSet.txt that is word
  seperated, and sorted followed by feature values)
-preprocessed_train.txt(this file holds the data of the trainingSet.txt that is
  word seperated, and sorted followed by feature values)
